import os
from ament_index_python.packages import get_package_share_directory

import launch
import launch_ros.actions
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource

def generate_launch_description():
    # Find the location of the package on your computer
    example_pkg_path_1 = get_package_share_directory('orbbec_camera')
    example_pkg_path_2 = get_package_share_directory('sllidar_ros2')
    slam_pkg_path = get_package_share_directory('slam_toolbox')
    rosbot_pkg_path = get_package_share_directory('rosbot')
    laser_filters_config = os.path.join(rosbot_pkg_path, 'config/lidar_filters_config_a1.yaml')



    # Both launch files
    example_launch_1 = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(example_pkg_path_1, 'launch/dabai_dcw.launch.py')),
    )
    example_launch_2 = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(example_pkg_path_2, 'launch/view_sllidar_a1_launch.py')),
    )

    # Laser filter node
    laser_filter_node = Node(
            package='laser_filters',
            executable='scan_to_scan_filter_chain',
            output='screen',
            parameters=[laser_filters_config],
            remappings=[('scan', 'scan_raw'),
                        ('scan_filtered', 'scan')]
        )

    slam_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(slam_pkg_path, 'launch/online_sync_launch.py')),
	)
	
    # Your final returned LaunchDescription includes 
    # a list of all of the nodes, launch files, etc.
    return launch.LaunchDescription([
        example_launch_1,
        example_launch_2,
        laser_filter_node,
        slam_launch,
    ])


if __name__ == '__main__':
    # Create a LaunchDescription object
    ld = generate_launch_description()

    ls = launch.LaunchService()
    ls.include_launch_description(ld)
    ls.run()
