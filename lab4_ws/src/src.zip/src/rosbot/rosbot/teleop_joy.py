import rclpy
from rclpy.node import Node

from sensor_msgs.msg import Joy
from geometry_msgs.msg import Twist


class TeleopJoy(Node):

    def __init__(self):
        super().__init__('teleop_joy')

        self.joy_subscriber = self.create_subscription(
            Joy,
            '/ros_robot_controller/joy',
            self.joy_callback,
            10
        )

        self.cmd_vel_publisher = self.create_publisher(
            Twist,
            '/cmd_vel',
            10
        )

        self.get_logger().info('teleop_joy started')

    def joy_callback(self, msg):
        cmd_vel = Twist()

        # Joystick Axes
        forward_axis = 1
        turn_axis = 0

        if len(msg.axes) > max(forward_axis,turn_axis):
            cmd_vel.linear.x = msg.axes[forward_axis]
            cmd_vel.angular.z = msg.axes[turn_axis]

        self.cmd_vel_publisher.publish(cmd_vel)


def main(args=None):
    rclpy.init(args=args)

    node = TeleopJoy()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()