from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'rosbot'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        (
            'share/ament_index/resource_index/packages',
            ['resource/rosbot']
        ),
        (
            'share/rosbot',
            ['package.xml']

        ),
        (
            'share/rosbot/launch',
            ['launch/launch.py']
        ),
        (
            os.path.join('share/rosbot/launch'),
            glob('launch/*launch.py')
        ),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='YOUR_NAME',
    maintainer_email='YOUR_EMAIL',
    description='Joystick teleoperation for the robot',
    license='TODO',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'teleop_joy = rosbot.teleop_joy:main',
        ],
    },
)
